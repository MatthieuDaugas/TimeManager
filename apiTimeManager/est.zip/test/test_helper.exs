ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(ApiTimeManager.Repo, :manual)
