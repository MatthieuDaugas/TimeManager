<template>
  <div class="ChartManager">
    <h1>This is ChartManager page</h1>
  </div>
</template>